var mysql = require('mysql');
var connection = mysql.createConnection({
 connectionLimit: 10,
 host: 'dev-dbinstance.ci933tgd61ld.us-west-2.rds.amazonaws.com',
 user: 'root',
 password: 'unhappyorangeturtlE',
 database: 'gpadatabase'
});

exports.handler = (event, context, callback) => {
 context.callbackWaitsForEmptyEventLoop = false;
 var sql;
 var QueryName=event.QueryName;
 var IndustryID = event.IndustryID;
 var IndustryCode = event.IndustryCode;
 var IndustryName= event.IndustryName;
 var IsActive = event.IsActive;
 if(QueryName=="Save")
 {
    sql = "insert into Industries ( IndustryName ,IndustryCode,IsActive) values('"+IndustryName +"','"+IndustryCode+"','"+IsActive+"')";
 }
 if(QueryName=="Edit")
 {
    sql= "select * from Industries where IndustryID ='"+IndustryID +"'";
 }
 if(QueryName=="Update")
 {
     sql= "update Industries set IndustryName ='"+IndustryName  +"',IndustryCode ='"+IndustryCode +"',IsActive='"+IsActive+"' where IndustryID ='"+IndustryID +"'";
 }
 if(QueryName=="Delete")
 {
     sql= "update Industries set IsActive='N' where IndustryID ='"+IndustryID +"'";
 }
 if(QueryName == "Read")
 {
     sql="select IndustryID,IndustryCode,IndustryName,(CASE WHEN IsActive='Y' THEN 'Yes' WHEN IsActive='N' THEN 'No' ELSE '' END)As IsActive from Industries order by IsActive Desc";
 }
  connection.query(sql, function (error, results, fields) {
    if (error) {
      console.log(error);
      callback(error, null);
    } else {
      console.log(results);
      callback(null, results);
    }
    //process.exit();
  });
}