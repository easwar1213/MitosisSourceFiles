
exports.handler = function(event, context,callback) {
    
	const AWS = require('aws-sdk');
    var s3 = new AWS.S3();
    //S3 Path Setup
    var MainFolderName=event.MainFolderName;
    var SubFolderName=event.SubFolderName;
    var MailDocName=event.MailDocName;
    var LangCode=event.LangCode;
    //Mail Setup
    var EmailTo=event.EmailTo;
    var User;
    var Pwd;
    var FileName;
    var MailSubject;
    var MailContent;
    var AttachFileName;
    if(MailDocName=="POA")
    {
        User="no-reply@globalpensionassociates.com";
        Pwd="Markrocks2018";
        MailSubject="GPA-Power Of Attorney"
        MailContent="Please find the below attached Power Of Attorney Form.You could take 3 hard copy of POA and signed & send back to GPA."
        AttachFileName="PowerOfAttorney.pdf";
        if(LangCode=="en")
        {
            FileName=MainFolderName+"/"+SubFolderName+"/"+"poa_en.pdf";
        }
        if(LangCode=="es")
        {
            FileName=MainFolderName+"/"+SubFolderName+"/"+"poa_es.pdf";
        }
        if(LangCode=="du")
        {
            FileName=MainFolderName+"/"+SubFolderName+"/"+"poa_du.pdf";
        }
        if(LangCode=="ge")
        {
            FileName=MainFolderName+"/"+SubFolderName+"/"+"poa_ge.pdf";
        }
        if(LangCode=="kr")
        {
            FileName=MainFolderName+"/"+SubFolderName+"/"+"poa_kr.pdf";
        }
    }
    if(MailDocName=="TC")
    {
        User="no-reply@globalpensionassociates.com";
        Pwd="Markrocks2018";
        MailSubject="GPA-Copy of Terms and Condition"
        MailContent="Please find the below attached Terms and Condition."
        AttachFileName="Terms_and_Conditions.pdf";
        if(LangCode=="en")
        {
            FileName=MainFolderName+"/"+SubFolderName+"/"+"terms_en.html.pdf";
        }
        if(LangCode=="es")
        {
            FileName=MainFolderName+"/"+SubFolderName+"/"+"terms_es.html.pdf";
        }
        if(LangCode=="du")
        {
            FileName=MainFolderName+"/"+SubFolderName+"/"+"terms_du.html.pdf";
        }
        if(LangCode=="ge")
        {
            FileName=MainFolderName+"/"+SubFolderName+"/"+"terms_ge.html.pdf";
        }
        if(LangCode=="kr")
        {
            FileName=MainFolderName+"/"+SubFolderName+"/"+"terms_kr.html.pdf";
        }
    }
    
    var email 	= require("emailjs/email");
    var server 	= email.server.connect({
        user:    User, 
		password:Pwd, 
		host:    "smtp.gmail.com",
		ssl:     true,
        timeout: 100000
    });
    var params = {
        "Bucket": "gpa-dev-mitosis",
        "Key": FileName
    };
    
       s3.getObject(params, function(err, data){
       if(err) {
           callback(err, null);
       } else {
           let response = {
        "statusCode": 200,
        "headers": {
            "my_header": "my_value"
        },
        "body": new Buffer(data.Body, 'binary').toString('base64')
    };
      server.send({
		  text:    MailContent, 
		  from:    User, 
		  to:      EmailTo,
		//cc:      "else <else@your-email.com>",
		  subject: MailSubject,
		 attachment: [
			{data: data.Body.toString('base64'), encoded:true, type:"application/pdf", name:AttachFileName}
		  ]
	   }, function(err, message) 
	        { 
	            if(err){
	                callback(err,null);
	            }else{
	                callback(null,message);
	            }
	            console.log(err || message); 
	            
	        }
	  );
    }
    });
}