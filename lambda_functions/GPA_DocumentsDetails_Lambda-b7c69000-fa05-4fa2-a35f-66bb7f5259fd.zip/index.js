var mysql = require('mysql');
var connection = mysql.createConnection({
 connectionLimit: 10,
 host: 'dev-dbinstance.ci933tgd61ld.us-west-2.rds.amazonaws.com',
 user: 'root',
 password: 'unhappyorangeturtlE',
 database: 'gpadatabase'
});

exports.handler = (event, context, callback) => {
 context.callbackWaitsForEmptyEventLoop = false;
 var sql;
 var QueryName=event.QueryName;
 var DocumentID=event.DocumentID;
 var DocumentName  = event.DocumentName;
 var DocumentTypeID = event.DocumentTypeID;
 var Description = event.Description;
 var DocTranType=event.DocTranType;
 var IsActive = event.IsActive;
 if(QueryName=="Save")
 {
    sql = "insert into Documents (DocumentName,DocumentTypeID,Description,DocTranType,IsActive) values('"+DocumentName+"','"+DocumentTypeID+"','"+Description+"','"+DocTranType+"','"+IsActive+"')";
 }
 if(QueryName=="Edit")
 {
    sql= "select * from Documents where DocumentID ='"+DocumentID+"'";
 }
 if(QueryName=="Update")
 {
     sql= "update Documents set DocumentName ='"+DocumentName +"',DocumentTypeID ='"+DocumentTypeID +"',Description='"+Description+"',DocTranType='"+DocTranType+"',IsActive='"+IsActive+"' where DocumentID ='"+DocumentID +"'";
 }
 if(QueryName=="Delete")
 {
     sql= "update Documents set IsActive='N' where DocumentID ='"+DocumentID +"'";
 }
 if(QueryName == "Read")
 {
     sql="select D.DocumentID,D.DocumentName,DT.DocumentType,D.Description,D.DocTranType,(CASE WHEN D.DocTranType='S' THEN 'Send' WHEN D.DocTranType='R' THEN 'Receive' WHEN D.DocTranType='B' THEN 'Both' ELSE '' END)As DocTranType,(CASE WHEN D.IsActive='Y' THEN 'Yes' WHEN D.IsActive='N' THEN 'No' ELSE '' END) As IsActive from Documents D inner join DocumentTypes DT on D.DocumentTypeID=DT.DocumentTypeID order by D.IsActive Desc";
 }
  connection.query(sql, function (error, results, fields) {
    if (error) {
      console.log(error);
      callback(error, null);
    } else {
      console.log(results);
      callback(null, results);
    }
    //process.exit();
  });
}