var AWS = require('aws-sdk');
var s3 = new AWS.S3();
var KEY_NAME;
var BUCKET_NAME = "gpa-dev-mitosis";  // bucket path
var PATH;  //folder path
var AppCode;   
var data_utf8;
exports.handler = (event, context, callback) => {
	context.callbackWaitsForEmptyEventLoop = false;
  var FileJSONObj= event.FileJSONObj;
   FileJSONObj.map(function (item, index) {
   	console.log("certificatename="+item.CertificateName);
   	console.log("AppCode="+item.AppCode);
   	if(item.CertificateName=="DOB")
	{
	    KEY_NAME="AppBirthCertificate"; 
	}
	if(item.CertificateName=="DOM"){
	    KEY_NAME="AppMarriageCertificate"; 
	}
	if(item.CertificateName=="BDF"){
	    KEY_NAME="AppBankDepositForm"; 
	}
	if(item.CertificateName=="ODC"){
	    KEY_NAME="AppOtherDocument"; 
	}
	console.log("keyname="+KEY_NAME);
	data_utf8 = new Buffer(item.html_base64, 'base64');
	AppCode= item.AppCode;
	PATH="applicant/"+AppCode+"/"+"Certificates/";   //folder path
     var params = {
       "Body": data_utf8,
       "Bucket": BUCKET_NAME,
       "Key": PATH + KEY_NAME +".pdf"  
    };
     s3.putObject(params, function(err, data) {
      if (err) {
        console.log(err);
      } else {
        context.done(null, { pdf_base64: data_utf8.toString('base64') });
      }
    });
   });
};