const AWS = require('aws-sdk');
//*/ get reference to S3 client 
var s3 = new AWS.S3();
exports.handler = (event, context, callback) => {
// var path="https://s3-us-west-2.amazonaws.com/gpa-dev-mitosis/files/TermsCondition.pdf"

    var params = {
  "Bucket": "gpa-dev-mitosis",
  //"Key": "applicant/emp006/terms_en.html.pdf"
  "Key": "pdf_templates/terms_cond.html"

    };
    s3.getObject(params, function(err, data){
       if(err) {
           callback(err, null);
       } else {
           let response = {
        "statusCode": 200,
        "headers": {
            "my_header": "my_value"
        },
        "body": new Buffer(data.Body, 'binary').toString('utf8')
    };
           callback(null, response);
    }
    });
};