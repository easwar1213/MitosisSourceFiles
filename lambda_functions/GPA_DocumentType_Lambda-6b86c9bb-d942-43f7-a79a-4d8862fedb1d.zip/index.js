var mysql = require('mysql');
var connection = mysql.createConnection({
 connectionLimit: 10,
 host: 'dev-dbinstance.ci933tgd61ld.us-west-2.rds.amazonaws.com',
 user: 'root',
 password: 'unhappyorangeturtlE',
 database: 'gpadatabase'
});

exports.handler = (event, context, callback) => {
 context.callbackWaitsForEmptyEventLoop = false;
 var sql;
 var QueryName=event.QueryName;
 var DocumentTypeID = event.DocumentTypeID;
 var DocumentType = event.DocumentType;
 var Description = event.Description;
 var IsActive = event.IsActive;
 if(QueryName=="Save")
 {
    sql = "insert into DocumentTypes (DocumentType,Description,IsActive) values('"+DocumentType+"','"+Description+"','"+IsActive+"')";
 }
 if(QueryName=="Edit")
 {
    sql= "select * from DocumentTypes where DocumentTypeID ='"+DocumentTypeID+"'";
 }
 if(QueryName=="Update")
 {
     sql= "update DocumentTypes set DocumentType ='"+DocumentType +"',Description ='"+Description +"' ,IsActive='"+IsActive+"'where DocumentTypeID ='"+DocumentTypeID +"'";
 }
 if(QueryName=="Delete")
 {
     sql= "update DocumentTypes set IsActive='N' where DocumentTypeID ='"+DocumentTypeID +"'";
 }
 if(QueryName == "Read")
 {
     sql="select DocumentTypeID,DocumentType,Description,(CASE WHEN IsActive='Y' THEN 'Yes' WHEN IsActive='N' THEN 'No' ELSE '' END) As IsActive from DocumentTypes order by IsActive Desc";
 }
  connection.query(sql, function (error, results, fields) {
    if (error) {
      console.log(error);
      callback(error, null);
    } else {
      console.log(results);
      callback(null, results);
    }
    //process.exit();
  });
}