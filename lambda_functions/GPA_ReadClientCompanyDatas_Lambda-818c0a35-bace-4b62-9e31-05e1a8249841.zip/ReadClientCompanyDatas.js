var mysql = require('mysql');
var connection = mysql.createConnection({
  connectionLimit: 10,
  host: 'dev-dbinstance.ci933tgd61ld.us-west-2.rds.amazonaws.com',
  user: 'root',
  password: 'unhappyorangeturtlE',
  database: 'gpadatabase'
});

exports.handler = (event, context, callback) => {
  context.callbackWaitsForEmptyEventLoop = false;
  var sql;
  var QueryName=event.QueryName;
  var CompanyID=event.CompanyID;
  var EmployeeID=event.EmployeeID;
  var UserID=event.UserID;
  if(QueryName=="AR")
  {
    sql = "select Cli.CompanyCode,Cli.CompanyName,Cli.CompanyLogo,Emp.EmployeeCode,Emp.EmpFirstName,Emp.EmpMiddleName,Emp.EmpLastName,Emp.Email,Emp.PhoneNum,Emp.HomeNum from ClientCompanyEmployees Emp Inner Join ClientCompanies Cli on Emp.CompanyCode=Cli.CompanyCode where Cli.CompanyCode='"+CompanyID+"' and Emp.EmployeeCode='"+EmployeeID+"'";
  }
  if(QueryName=="TC")
  {
    sql = "select Cli.CompanyCode,Cli.CompanyName,Emp.EmployeeCode,Emp.Email from ClientCompanyEmployees Emp Inner Join ClientCompanies Cli on Emp.CompanyCode=Cli.CompanyCode where Emp.Email='"+UserID+"'";
  }
  if(QueryName=="DR")
  {
    sql = "select Cli.CompanyCode,Cli.CompanyName,Cli.CompanyLogo,Emp.EmployeeCode,Emp.EmpFirstName,Emp.EmpMiddleName,Emp.EmpLastName,Emp.Email,Emp.PhoneNum,Emp.HomeNum,Emp.SSNum,Emp.DOB_Day,Emp.DOB_Month,Emp.DOB_Year from ClientCompanyEmployees Emp Inner Join ClientCompanies Cli on Emp.CompanyCode=Cli.CompanyCode where Cli.CompanyCode='"+CompanyID+"' and Emp.Email='"+UserID+"'";
  }
  if(QueryName=="BQ")
  {
    sql = "select RC.CompanyCode,C.CompanyName from ResidencyQuestionnariesEmpCompany RC inner join ResidencyQuestionnaries RQ on RC.ResQusID=RQ.ResQusID inner join ClientCompanies C on RC.CompanyCode=C.CompanyCode Where RQ.UserID='"+UserID+"'";
  }
  if(QueryName=="IM")
  {
    sql = "select CompanyCode,Email from ClientCompanyEmployees Where Email='"+event.UserID+"' and CompanyCode='"+event.CompanyID+"'";
  }
  connection.query(sql, function (error, results, fields) {
    if (error) {
      console.log(error);
      callback(error, null);
    } else {
      console.log(results);
      callback(null, results);
    }
    //process.exit();
  });
}