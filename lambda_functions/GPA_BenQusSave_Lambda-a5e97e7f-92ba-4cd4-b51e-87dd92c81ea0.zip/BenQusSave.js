var mysql = require('mysql');
var connection = mysql.createConnection({
 connectionLimit: 10,
 host: 'dev-dbinstance.ci933tgd61ld.us-west-2.rds.amazonaws.com',
 user: 'root',
 password: 'unhappyorangeturtlE',
 database: 'gpadatabase'
});

exports.handler = (event, context, callback) => {
 context.callbackWaitsForEmptyEventLoop = false;
 var sql;
 var QueryName=event.QueryName;
 var HomeAddress=event.HomeAddress;
 var PlaceOfBirth=event.PlaceOfBirth;
 var Partner=event.Partner;
 var CountryCode=event.CountryCode;
 var Benefits=event.Benefits;
 var BenefitsName=event.BenefitsName;
 var GetBenefits=event.GetBenefits;
 var Receiving=event.Receiving;
 var ReferenceNum=event.ReferenceNum;
 var SSSecurity=event.SSSecurity;
 var SSSecurityAddress=event.SSSecurityAddress;
 var DateOfBenefits=event.DateOfBenefits;
 var CompanyCode=event.CompanyCode;
 var Occupation=event.Occupation;
 var IndustryCode=event.IndustryCode;
 var CompanyAddress=event.CompanyAddress;
 var EligibleCountry=event.EligibleCountry;
 var UserID =event.UserID;
 if(QueryName=="Save")
 {
    sql = "insert into BenQusCountryInGPA (UserID,HomeAddress,PlaceOfBirth,Partner,CountryCode,Benefits,BenefitsName,GetBenefits,Receiving,ReferenceNum,SSSecurity,SSSecurityAddress,DateOfBenefits,CompanyCode,Occupation,IndustryCode,CompanyAddress,EligibleCountry) values('"+UserID+"','"+HomeAddress+"','"+PlaceOfBirth+"','"+Partner+"','"+CountryCode+"','"+Benefits+"','"+BenefitsName+"','"+GetBenefits+"','"+Receiving+"','"+ReferenceNum+"','"+SSSecurity+"','"+SSSecurityAddress+"','"+DateOfBenefits+"','"+CompanyCode+"','"+Occupation+"','"+IndustryCode+"','"+CompanyAddress+"','"+EligibleCountry+"')";
 }
 if(QueryName=="Edit")
 {
    sql= "select * from BenQusCountryInGPA where UserID='"+UserID+"'";
 }
 if(QueryName=="Update")
 {
     sql= "update BenQusCountryInGPA set HomeAddress='"+HomeAddress+"',PlaceOfBirth='"+PlaceOfBirth+"',Partner='"+Partner+"',CountryCode='"+CountryCode+"',Benefits='"+Benefits+"',BenefitsName='"+BenefitsName+"',GetBenefits='"+GetBenefits+"',Receiving='"+Receiving+"',ReferenceNum='"+ReferenceNum+"',SSSecurity='"+SSSecurity+"',SSSecurityAddress='"+SSSecurityAddress+"',DateOfBenefits='"+DateOfBenefits+"',CompanyCode='"+CompanyCode+"',Occupation='"+Occupation+"',IndustryCode='"+IndustryCode+"',CompanyAddress='"+CompanyAddress+"',EligibleCountry='"+EligibleCountry+"' where UserID='"+UserID+"'";
 }
  connection.query(sql, function (error, results, fields) {
    if (error) {
      console.log(error);
      callback(error, null);
    } else {
      console.log(results);
      callback(null, results);
    }
    //process.exit();
  });
}