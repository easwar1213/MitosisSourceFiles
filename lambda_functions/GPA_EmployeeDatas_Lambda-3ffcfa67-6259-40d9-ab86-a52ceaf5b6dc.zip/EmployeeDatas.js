var mysql = require('mysql');
var AWS = require('aws-sdk');
var s3 = new AWS.S3();
var connection = mysql.createConnection({
  connectionLimit: 10,
  host: 'dev-dbinstance.ci933tgd61ld.us-west-2.rds.amazonaws.com',
  user: 'root',
  password: 'unhappyorangeturtlE',
  database: 'gpadatabase'
});

exports.handler = (event, context, callback) => {
  context.callbackWaitsForEmptyEventLoop = false;
  var sql;
  var EmployeeImg;
  var QueryName=event.QueryName;
  var UserID=event.UserID;
  var EmployeeID=event.EmployeeID;
  var EmployeeCode=event.EmployeeCode;
  var EmpFirstName=event.EmpFirstName;
  var EmpMiddleName=event.EmpMiddleName;
  var EmpLastName=event.EmpLastName;
  var PhoneNum=event.PhoneNum;
  var Email=event.EmailState;
  var CompanyName = event.CompanyName;
  var CompanyCode = event.CompanyID;
  var Gender = event.Gender;
  var EmployeeType = event.EmployeeType;
  var DOB_Day=event.DOB_Day;
  var DOB_Month=event.DOB_Month;
  var DOB_Year=event.DOB_Year;
  var HomeNum=event.HomeNo;
  var SSNum=event.SSNumberState;
  var IsActive=event.IsActive;
  var flag = false;
  var FileExtension = event.FileExtension;
  // if(FileExtension.indexOf('j')>-1)
  // {
  //   FileExtension = ".jpg";
  // }
  // else
  // {
  //   FileExtension = ".pn"
  // }
  //var FileExtension = ".jpg";
  if(QueryName=="Save")
  {
    sql = "insert into ClientCompanyEmployees(EmployeeCode,CompanyCode,EmpFirstName,EmpMiddleName,EmpLastName,EmployeeType,Gender,DOB_Day,DOB_Month,DOB_Year,SSNum,PhoneNum,HomeNum,Email) values ('"+EmployeeCode+"','"+CompanyCode+"','"+EmpFirstName+"','"+EmpMiddleName+"','"+EmpLastName+"','"+EmployeeType+"','"+Gender+"','"+DOB_Day+"','"+DOB_Month+"','"+DOB_Year+"','"+SSNum+"','"+PhoneNum+"','"+HomeNum+"','"+Email+"')";
  }
  if(QueryName=="Update")
  {
    sql = "update ClientCompanyEmployees set EmployeeCode='"+EmployeeCode+"',CompanyCode='"+CompanyCode+"',EmpFirstName='"+EmpFirstName+"',EmpMiddleName='"+EmpMiddleName+"',EmpLastName='"+EmpLastName+"',EmployeeType='"+EmployeeType+"',Gender='"+Gender+"',DOB_Day='"+DOB_Day+"',DOB_Month='"+DOB_Month+"',DOB_Year='"+DOB_Year+"',SSNum='"+SSNum+"',PhoneNum='"+PhoneNum+"',HomeNum='"+HomeNum+"',Email='"+Email+"' where EmployeeCode='"+EmployeeCode+"'";
  }
  if(QueryName=="Delete")
  {
    sql = "update ClientCompanyEmployees set IsActive='N' where EmployeeCode='"+EmployeeCode+"'";
  }
  if(QueryName=="Edit")
  {
    sql = "select * from ClientCompanyEmployees where EmployeeCode='"+EmployeeCode+"'";
  }
  if(QueryName=="ReadLogo")
  {
    sql = "select EmployeeImg from ClientCompanyEmployees where Email='"+Email+"'";
  }
   if(QueryName=="Read")
  {
    //sql = "select EmployeeCode,CompanyCode,EmpFirstName,EmpMiddleName,EmpLastName,(CASE WHEN EmployeeType='C' THEN 'Current Employee' WHEN EmployeeType='R' THEN 'Retired' ELSE '' END) AS EmployeeType,(CASE WHEN Gender='M' THEN 'Male' WHEN Gender='F' THEN 'Female' ELSE '' END) AS Gender,DOB_Day,DOB_Month,DOB_Year,SSNum,PhoneNum,HomeNum,Email from ClientCompanyEmployees Where IsActive='Y'";
    sql = "select EmployeeCode,t2.CompanyName as CompanyName, EmpFirstName,EmpMiddleName,EmpLastName,(CASE WHEN EmployeeType='C' THEN 'Current Employee' WHEN EmployeeType='R' THEN 'Retired' ELSE '' END)AS EmployeeType,(CASE WHEN Gender='M' THEN 'Male' WHEN Gender='F' THEN 'Female' ELSE '' END) AS Gender,DOB_Day,DOB_Month,DOB_Year,SSNum,PhoneNum,HomeNum,t1.Email from ClientCompanyEmployees t1 inner join ClientCompanies t2 on t1.CompanyCode=t2.CompanyCode Where t1.IsActive='Y'";
    
  }
  if(QueryName=="Upload")
  {
    if(EmployeeImg!="") {
      flag=true;
      console.log("testing");
      console.log("image="+KEY_NAME + FileExtension);
  var BUCKET_NAME = "gpa-dev-mitosis";  // bucket path
	var PATH="applicant/"+Email+"/"+"ProfileImage/";  //folder path
	var KEY_NAME = EmployeeCode;  // file name
	console.log("image="+KEY_NAME + FileExtension);
	let encodedImage = event.EmployeeImg;
  let decodedImage = Buffer.from(encodedImage, 'base64');
	//var data_utf8 = new Buffer(event.EmployeeImg, 'base64').toString('utf8');

	var params = {
      Bucket : BUCKET_NAME,
      Key : PATH + Email + FileExtension,
      Body : decodedImage 
    }
    s3.upload(params, function(err, data) {
      if (err) {
        console.log(err)
      } else {
        //console.log(data);
        console.log(data.Location);
        //EmpImage = data.Location;
        //context.done(null, { pdf_base64: data_utf8.toString('base64') });
        sql = "update ClientCompanyEmployees set EmployeeImg='"+data.Location+"' where Email='"+Email+"'";
        console.log(sql);
      connection.query(sql, function (error, results, fields) {
          if (error) {
            console.log(error);
            callback(error, null);
          } else {
            console.log(results);
            callback(null, results);
          }
          //process.exit();
        });
      }
    });
    }
  }
  if(flag==false){
  connection.query(sql, function (error, results, fields) {
    if (error) {
      console.log(error);
      callback(error, null);
    } else {
      console.log(results);
      callback(null, results);
    }
    //process.exit();
  });
  }
}