var mysql = require('mysql');
var connection = mysql.createConnection({
 connectionLimit: 10,
 host: 'dev-dbinstance.ci933tgd61ld.us-west-2.rds.amazonaws.com',
 user: 'root',
 password: 'unhappyorangeturtlE',
 database: 'gpadatabase'
});

exports.handler = (event, context, callback) => {
 context.callbackWaitsForEmptyEventLoop = false;
 var sql;
 var QueryName=event.QueryName;
 var CBDocumentID = event.CBDocumentID;
 var DocumentID = event.DocumentID;
 var CountryCode = event.CountryCode;
 var IsRequired = event.IsRequired;
 var IsActive = event.IsActive;
 if(QueryName=="Save")
 {
    sql = "insert into CountryBasedDocuments (DocumentID,CountryCode,IsRequired,IsActive) values('"+DocumentID+"','"+CountryCode+"','"+IsRequired+"','"+IsActive+"')";
 }
 if(QueryName=="Edit")
 {
    sql= "select * from CountryBasedDocuments where CBDocumentID ='"+CBDocumentID+"'";
 }
 if(QueryName=="Update")
 {
     sql= "update CountryBasedDocuments set DocumentID ='"+DocumentID +"',CountryCode ='"+CountryCode +"',IsRequired='"+IsRequired+"',IsActive='"+IsActive+"' where CBDocumentID ='"+CBDocumentID +"'";
 }
 if(QueryName=="Delete")
 {
     sql= "update CountryBasedDocuments set IsActive='N' where CBDocumentID ='"+CBDocumentID +"'";
 }
 if(QueryName == "Read")
 {
     sql="select CBD.CBDocumentID,D.DocumentName,C.CountryName,(CASE WHEN CBD.IsRequired='Y' THEN 'Yes' WHEN CBD.IsRequired='N' THEN 'No' ELSE '' END) As IsRequired,(CASE WHEN CBD.IsActive='Y' THEN 'Yes' WHEN CBD.IsActive='N' THEN 'No' ELSE '' END) As IsActive from CountryBasedDocuments CBD inner join Countries C on CBD.CountryCode=C.CountryCode inner join Documents D on CBD.DocumentID=D.DocumentID order by CBD.IsActive Desc";
 }
  connection.query(sql, function (error, results, fields) {
    if (error) {
      console.log(error);
      callback(error, null);
    } else {
      console.log(results);
      callback(null, results);
    }
    //process.exit();
  });
}