var mysql = require('mysql');
var connection = mysql.createConnection({
  connectionLimit: 10,
  host: 'dev-dbinstance.ci933tgd61ld.us-west-2.rds.amazonaws.com',
  user: 'root',
  password: 'unhappyorangeturtlE',
  database: 'gpadatabase'
});

exports.handler = (event, context, callback) => {
  context.callbackWaitsForEmptyEventLoop = false;
  var sql;
  var QueryName=event.QueryName;
  if(QueryName=="Countries")
  {
    sql="select CountryCode,CountryName from Countries where IsActive='Y'";
  }
  if(QueryName=="Industries")
  {
    sql="select IndustryCode,IndustryName from Industries where IsActive='Y'";
  }
  if(QueryName=="ClientCompanies")
  {
    sql="select CompanyCode,CompanyName from ClientCompanies where IsActive='Y'";
  }
  connection.query(sql, function (error, results, fields) {
    if (error) {
      console.log(error);
      callback(error, null);
    } else {
      console.log(results);
      callback(null, results);
    }
    //process.exit();
  });
}