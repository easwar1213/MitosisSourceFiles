var mysql = require('mysql');
var aws = require('aws-sdk');
var ses = new aws.SES({
   region: 'us-west-2'
});
var connection = mysql.createConnection({
  connectionLimit: 10,
  host: 'dev-dbinstance.ci933tgd61ld.us-west-2.rds.amazonaws.com',
  user: 'root',
  password: 'unhappyorangeturtlE',
  database: 'gpadatabase'
});

exports.handler = (event, context, callback) => {
  context.callbackWaitsForEmptyEventLoop = false;
  var emailList = event.EmailList;
  var result=[];
  result.length=0;
  result = emailList.toString().split(',');
  result.forEach(function (item, index) {  
  item= item.replace(/[\r\n]/g, ""); 
  var sql = "select CompanyCode,EmployeeCode from ClientCompanyEmployees where Email='" + item + "'";   //console.log(sql);  
  connection.query(sql, function (error, results, fields) {
    if (error) {
     // console.log(error);
      callback(error, null);
    } else {
   //  console.log(results);
     var CompanyCode = results[0].CompanyCode;
     var EmployeeCode = results[0].EmployeeCode; 
    // console.log(CompanyCode);
    // console.log(EmployeeCode);
     var eParams = {
        Destination: {
            ToAddresses: [item]
        },
        Message: {
            Body: {
                Text: {
                    Data: "http://gpa-hosting.s3-website-us-west-2.amazonaws.com/?CompanyID="+CompanyCode +"&EmployeeID="+EmployeeCode+""
                }
            },
            Subject: {
                Data: "GPA-Applicant Pension Apply Link!!!"
            }
        },
        Source: "no-reply@globalpensionassociates.com"
    };

    console.log('===SENDING EMAIL===');
    var email = ses.sendEmail(eParams, function(err, data){
        if(err) console.log(err);
        else {
            console.log(emailList)
            console.log("===EMAIL SENT===");
            console.log(data);


            console.log("EMAIL CODE END");
            console.log('EMAIL: ', email);
            context.succeed(event);

        }
    });     
    }   
  });
  });
}