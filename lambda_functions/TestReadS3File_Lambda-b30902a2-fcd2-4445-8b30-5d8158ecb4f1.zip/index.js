
exports.handler = function(event, context,callback) {
   
   var email 	= require("emailjs/email");
   
   var server 	= email.server.connect({
      user:    "no-reply@globalpensionassociates.com", 
		password:"Markrocks2018", 
		host:    "smtp.gmail.com",
		ssl:     true,
      timeout: 100000
      
   });
   
 //  if(event.fileBase64String){
	  // send the message and get a callback with an error or details of the message that was sent
	  server.send({
		  text:    "Please find the below Terms and Condition attachment", 
		  from:    "no-reply@globalpensionassociates.com", 
		  to:       "pitchaimuthu.k@mitosistech.com", //event.to,
		  cc:      "else <else@your-email.com>",
		  subject: "GPA-Copy of Terms and Condition"
		// attachment: [
		//	{data: event.fileBase64String, encoded:true, type:"application/pdf", name:"Terms_and_Conditions.pdf"}
		//  ]
	   }, function(err, message) 
	        { 
	            if(err){
	                callback(err,null);
	            }else{
	                callback(null,message);
	            }
	            console.log(err || message); 
	            
	        }
	  );
 //  }
   
}