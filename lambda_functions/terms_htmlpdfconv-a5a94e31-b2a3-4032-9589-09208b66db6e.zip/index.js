var wkhtmltopdf = require('wkhtmltopdf');
var MemoryStream = require('memorystream');
var AWS = require('aws-sdk');

process.env['PATH'] = process.env['PATH'] + ':' + process.env['LAMBDA_TASK_ROOT'];

var convertToPdf = function(htmlUtf8, event, callback) {
  var memStream = new MemoryStream();

  wkhtmltopdf(htmlUtf8, event.options, function(code, signal) {
	  console.log('htmltext:' ,  htmlUtf8);
	  console.log('memstream:' ,  memStream.read().toString());

    callback(memStream.read());
  }).pipe(memStream);
}

var updateContent  = function(cntnt , key , value ) {

	//var regex = /key/g;
    return cntnt.replace(key, value);
}

exports.handler = function(event, context) {
	var BUCKET_NAME = "gpa-dev-mitosis";
	var KEY_NAME ="terms_en.html";
	var TEMPLATE_PATH="template/termscondition/"

	var OUTPUT_PATH="applicant/"

  var memStream = new MemoryStream();
 // var html_utf8 = new Buffer(event.html_base64, 'base64').toString('utf8');
  var html_utf8 =event.html;

  var inputparam = event.params ; 

  var firstName =  ""
  var middleName =  "";
  var lastName =  "";
  var signedBy =  "";
  var companyName = "";
  var empSignature = "";
  var empId = "";
  var lang_locale="en";
  var signedbyname = "";

if( typeof inputparam != 'undefined' &&   inputparam.hasOwnProperty("empId"))
	{
	  var firstName =  inputparam.firstName;
	  var middleName =  inputparam.middleName;
	  var lastName =  inputparam.lastName;
	  var signedBy =  inputparam.signedBy;
	  var companyName = inputparam.companyName;
	  var empSignature = inputparam.empSignature;
	  var empId = inputparam.empId;
	  var lang_locale =  inputparam.lang;
	  var signedbyname = inputparam.signedbyname;


	  if( typeof lang_locale != 'undefined')
	  KEY_NAME = "terms_" + lang_locale + ".html";


	  OUTPUT_PATH = OUTPUT_PATH + empId + "/";

		 // read data from s3 bucket 
		  var params = {Bucket: BUCKET_NAME, Key: TEMPLATE_PATH + KEY_NAME};
			new AWS.S3().getObject(params, function(err, data)
			{
			  if (!err) {
				html_utf8 = data.Body.toString('utf-8');

				console.log('file :', html_utf8);

			// replace the dyanamic value
				html_utf8 = updateContent(html_utf8 , '${firstName}',firstName);
				html_utf8 = updateContent(html_utf8 , '${middleName}',middleName);
				html_utf8 = updateContent(html_utf8 , '${lastName}',lastName);
				html_utf8 = updateContent(html_utf8 , '${signedby}',signedBy);
				html_utf8 = updateContent(html_utf8 , '${EmpCompanyName}',companyName);
				html_utf8 = updateContent(html_utf8 , '${EmpCompanyName}',companyName);
				html_utf8 = updateContent(html_utf8 , '${EmpCompanyName}',companyName);
				html_utf8 = updateContent(html_utf8 , '${EmpCompanyName}',companyName);
				html_utf8 = updateContent(html_utf8 , '${EmpCompanyName}',companyName);
				html_utf8 = updateContent(html_utf8 , '${signedbyname}',signedbyname);

				html_utf8 = updateContent(html_utf8 , '${SignaturePad}',empSignature);


				console.log('afterreplace :', html_utf8);
				wkhtmltopdf(html_utf8, event.options, function(code, signal) {
			var pdf = memStream.read();
	

		   var s3 = new AWS.S3();
			var params = {
			  Bucket : BUCKET_NAME,
			  Key : OUTPUT_PATH + KEY_NAME +".pdf",
			  Body : pdf
			}

			s3.putObject(params, function(err, data) {
			  if (err) {
				console.log(err)
					context.done(null, { status:'error',  err: err , msg : 'file write error', filename: params.Key});
					context.done(null, { filename:params.Key,  content: pdf});				

			  } else {
				//context.done(null, { status:'success',  filename: html_utf8 });
				context.done(null, { status:'success',  filename: params.Key });

			  }
			});
		  }).pipe(memStream);


			 }else
				{
					console.log('file read error:', err);
					context.done(null, { status:'error',  err: err , msg:'file read error'});
				}

		   });
	}else
	{
					console.log('invalid Input param ');
					context.done(null, { status:'error',  msg: 'invalid input parameter' });

	}

};


