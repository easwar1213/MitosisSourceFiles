var mysql = require('mysql');
var connection = mysql.createConnection({
  connectionLimit: 10,
  host: 'dev-dbinstance.ci933tgd61ld.us-west-2.rds.amazonaws.com',
  user: 'root',
  password: 'unhappyorangeturtlE',
  database: 'gpadatabase'
});

exports.handler = (event, context, callback) => {
  context.callbackWaitsForEmptyEventLoop = false;
  var sql = "select * from QusRuleEngine";
  connection.query(sql, function (error, results, fields) {
    if (error) {
      console.log(error);
      callback(error, null);
    } else {
      console.log(results);
      callback(null, results);
    }
    //process.exit();
  });
}