exports.handler = function(event, context) {
    if(event.userPoolId === "us-west-2_Ra8meVRTO") {
        if(event.triggerSource === "GPA_Registration_Link") {
            event.response.verificationType = "Link";
          //  event.response.smsMessage = "Welcome to the service. Your confirmation code is " + event.request.codeParameter;
            event.response.emailSubject = "Welcome to the service";
           // event.response.emailMessage = "Thank you for signing up. " + event.request.codeParameter + " is your verification code";
           // event.response.emailMessage = "Your Confirmation Code is:{####}";
           event.response.emailMessage = "Thank you for signing up. http://gpa-dev.s3-website-us-west-2.amazonaws.com/ConfirmationCode?confirmationid={####}&user_name="+event.userName;

        
    }
    }
    else{
        event.response = "Hellow";
    }
    context.done(null, event);
};