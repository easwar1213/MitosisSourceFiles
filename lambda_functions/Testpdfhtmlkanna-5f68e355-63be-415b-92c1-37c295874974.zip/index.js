var wkhtmltopdf = require('wkhtmltopdf');
var MemoryStream = require('memorystream');
var AWS = require('aws-sdk');

process.env['PATH'] = process.env['PATH'] + ':' + process.env['LAMBDA_TASK_ROOT'];

var convertToPdf = function(htmlUtf8, event, callback) {
  var memStream = new MemoryStream();

  wkhtmltopdf(htmlUtf8, event.options, function(code, signal) {
	  console.log('htmltext:' ,  htmlUtf8);
	  console.log('memstream:' ,  memStream.read().toString());

    callback(memStream.read());
  }).pipe(memStream);
}

exports.handler = function(event, context) {
	var BUCKET_NAME = "gpa-dev-mitosis";
	var KEY_NAME ="test2.html";

  var memStream = new MemoryStream();
 // var html_utf8 = new Buffer(event.html_base64, 'base64').toString('utf8');
  var html_utf8 =event.html;

 // read data from s3 bucket 
  var params = {Bucket: BUCKET_NAME, Key: KEY_NAME};
    new AWS.S3().getObject(params, function(err, data)
    {
      if (!err) {
        html_utf8 = data.Body.toString('utf-8');


	    wkhtmltopdf(html_utf8, event.options, function(code, signal) {
    var pdf = memStream.read();
    var s3 = new AWS.S3();

   var s3 = new AWS.S3();
	var params = {
      Bucket : BUCKET_NAME,
      Key : KEY_NAME +".pdf",
      Body : pdf
    }

    s3.putObject(params, function(err, data) {
      if (err) {
        console.log(err)
      } else {
        context.done(null, { pdf_base64: pdf.toString('base64') });
      }
    });
  }).pipe(memStream);


     }else
		{
			console.log('file read error:', err);
			context.done(null, err);
		}

   });

/*
 wkhtmltopdf(html_utf8, event.options, function(code, signal) {
    var pdf = memStream.read();
    var s3 = new AWS.S3();

   var s3 = new AWS.S3();
	var params = {
      Bucket : BUCKET_NAME,
      Key : KEY_NAME +".pdf",
      Body : pdf
    }

    s3.putObject(params, function(err, data) {
      if (err) {
        console.log(err)
      } else {
        context.done(null, { pdf_base64: pdf.toString('base64') });
      }
    });
  }).pipe(memStream);
  */
};


