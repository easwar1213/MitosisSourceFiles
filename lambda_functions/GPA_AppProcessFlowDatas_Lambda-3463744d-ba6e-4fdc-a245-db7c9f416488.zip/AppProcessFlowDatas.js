var mysql = require('mysql');
var connection = mysql.createConnection({
  connectionLimit: 10,
  host: 'dev-dbinstance.ci933tgd61ld.us-west-2.rds.amazonaws.com',
  user: 'root',
  password: 'unhappyorangeturtlE',
  database: 'gpadatabase'
});

exports.handler = (event, context, callback) => {
  context.callbackWaitsForEmptyEventLoop = false;
  var sql;
  var QueryName=event.QueryName;
  var UserID=event.UserID;
  var Welcome=event.Welcome;
  var TC=event.TC;
  var HowToStart=event.HowToStart;
  var GenQus=event.GenQus;
  var ResQus=event.ResQus;
  var BenQus=event.BenQus;
  var POA=event.POA;
  var OtherDoc=event.OtherDoc;
  var Forecast=event.Forecast;
  var IsActive=event.IsActive;
  
  if(QueryName=="Save")
  {
    sql = "insert into ApplicantProcessFlowTracking(UserID) values('"+UserID+"')";
  }
  if(QueryName=="UpdateWel")
  {
    sql = "update ApplicantProcessFlowTracking set Welcome='"+Welcome+"' where UserID='"+UserID+"'";
  }
  if(QueryName=="UpdateTC")
  {
    sql = "update ApplicantProcessFlowTracking set TC='"+TC+"' where UserID='"+UserID+"'";
  }
  if(QueryName=="UpdateHTS")
  {
    sql = "update ApplicantProcessFlowTracking set HowToStart='"+HowToStart+"'where UserID='"+UserID+"'";
  }
  if(QueryName=="UpdateGQ")
  {
    sql = "update ApplicantProcessFlowTracking set GenQus='"+GenQus+"' where UserID='"+UserID+"'";
  }
  if(QueryName=="UpdateRQ")
  {
    sql = "update ApplicantProcessFlowTracking set ResQus='"+ResQus+"'where UserID='"+UserID+"'";
  }
  if(QueryName=="UpdateBQ")
  {
    sql = "update ApplicantProcessFlowTracking set BenQus='"+BenQus+"'where UserID='"+UserID+"'";
  }
  if(QueryName=="UpdatePOA")
  {
    sql = "update ApplicantProcessFlowTracking set POA='"+POA+"' where UserID='"+UserID+"'";
  }
  if(QueryName=="UpdateOD")
  {
    sql = "update ApplicantProcessFlowTracking set OtherDoc='"+OtherDoc+"' where UserID='"+UserID+"'";
  }
  if(QueryName=="UpdateFCL")
  {
    sql = "update ApplicantProcessFlowTracking set Forecast='"+Forecast+"' where UserID='"+UserID+"'";
  }
  if(QueryName=="Delete")
  {
    sql = "update ApplicantProcessFlowTracking set IsActive='N' where UserID='"+UserID+"'";
  }
  if(QueryName=="Read")
  {
    sql = "select * from ApplicantProcessFlowTracking Where IsActive='Y' and UserID='"+UserID+"'";
  }
  connection.query(sql, function (error, results, fields) {
    if (error) {
      console.log(error);
      callback(error, null);
    } else {
      console.log(results);
      callback(null, results);
    }
    //process.exit();
  });
}