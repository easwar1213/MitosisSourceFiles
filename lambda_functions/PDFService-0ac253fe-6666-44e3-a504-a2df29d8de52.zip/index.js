var fs = require('fs');
var html = fs.readFileSync('./pdf-templates/terms_cond.html', 'utf8');
console.log(html);

var data = {
	"firstName": "Karthee",
	"lastName": "Mitosis"
}

for (var key in data) {
    if (data.hasOwnProperty(key)) {
        html = html.replace("${"+key+"}", data[key]);
    }
}

var pdf = require('html-pdf');
var options = { format: 'Letter' };
pdf.create(html, options).toFile('tc.pdf', function(err, res) {
  if (err) return console.log(err);
  console.log(res); // { filename: '/app/businesscard.pdf' }
});

/*
pdf.create(html).toBuffer(function(err, buffer){
  console.log('This is a buffer:', Buffer.isBuffer(buffer));
});
*/