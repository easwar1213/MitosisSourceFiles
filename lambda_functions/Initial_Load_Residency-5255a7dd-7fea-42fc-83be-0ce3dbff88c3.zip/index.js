var mysql = require('mysql');

var pool = mysql.createPool({
    connectionLimit: 100,
    host: 'dev-dbinstance.ci933tgd61ld.us-west-2.rds.amazonaws.com',
    user: 'root',
    password: 'unhappyorangeturtlE',
    database: 'gpadatabase'
});
exports.handler = function (event, context, callback) {
    context.callbackWaitsForEmptyEventLoop = false;
    pool.getConnection(function (err, connection) {
        if (err) {
            var n = 0;
            callback(err, null);
        }
        var QueryRunMode = event.queryMode;
        if(QueryRunMode=="GetCountryData"){
              var query = "Call SP_GetResidencyCountry('"+event.UserID+"')";
                connection.query(query, function (error, res) {
                if (error) {
                  callback(error, null);
                } else {
                    connection.release();
                    callback(null,res);
                  //callback(null, results);
                }
              }); 
        }
        else  if(QueryRunMode=="GetCompanyData"){
             var query = "Call SP_GetResidencyCompany('"+event.UserID+"')";
                connection.query(query, function (error, results) {
                if (error) {
                  callback(error, null);
                } else {
                    connection.release();
                    callback(null,results);
                  //callback(null, results);
                }
              }); 
        }
        else if (QueryRunMode == "InitalLoad") {
            var reData = [];
            //get status from the Residency questionary table
            var getCompany = "Select ResQusStatus from gpadatabase.ResidencyQuestionnaries where UserID='" + event.UserID + "'"
            //EXECUTE THE QUERY
            connection.query(getCompany, function (err, row) {
                if (err) {
                    callback(err, null);
                } else {
                    reData.push(row[0]);
                    connection.release();
                    //connection.end();
                    callback(null, {
                        statusCode: '200',
                        body: reData,
                        headers: {
                            'Content-Type': 'application/json',
                        },
                    });
                }
            });
        }
        // Add Company Data
        else if (QueryRunMode == "AddCompany") {
            var UserID = event.UserID;
            var isCheck = "";
            var n = 0;
            var country = [];
            var sqlQuery3 = "Select ResQusID,UserID,ResQusStatus From ResidencyQuestionnaries where UserID='" + UserID + "'";
            connection.query(sqlQuery3, function (err, result) {
                if (err) {
                    callback(err, null);
                } else {
                    isCheck = result[0];
                    if (result[0] == null) {
                        var sqlQuery3 = "INSERT INTO ResidencyQuestionnaries(UserID,ResQusStatus)VALUES";
                        var exQuery3 = sqlQuery3 + "('" + event.UserID + "','" + event.ResStatus + "')";
                        connection.query(exQuery3, function (err, row) {
                            if (err) {
                                callback(err, null);
                            }
                            //callback(null,row);
                        });
                    }
                    var sqlResidency = "SELECT max(ResQusID) as ResQusID FROM gpadatabase.ResidencyQuestionnaries where UserID = '" + event.UserID + "'";
                    connection.query(sqlResidency, function (err, row) {
                        if (err) {
                            callback(err, null);
                        }
                        var ResidencyID = row[0].ResQusID;
                        var getCountry = "select CountryOfResidency from ResidencyQuestionnariesCountry where ResQusID='" + ResidencyID + "' and CountryOfResidency='" + event.Country + "'";
                        //EXECUTE THE QUERY
                        connection.query(getCountry, function (err, result) {
                            if (err) {
                                callback(err, null);
                            }
                            if (result[0] == null) {

                                var addCountry_exQuery = "INSERT INTO ResidencyQuestionnariesCountry(CountryOfResidency,ResCountry_BMonth,ResCountry_BYear,ResCountry_EMonth,ResCountry_EYear,PersonalIDNum,CurrentAddress,ResQusID)Values";
                                var addCountry_sqlQuery = addCountry_exQuery + "('" + event.Country + "', '" + event.ResMonth + "', '" + event.ResYear + "', '" + event.ResCountryMonth + "', '" + event.ResCountryYear + "', '" + event.PersonalID + "', '" + event.currentAddress + "', '" + ResidencyID + "')";
                                //EXECUTE THE QUERY
                                connection.query(addCountry_sqlQuery, function (err, row) {
                                    if (err) {
                                        callback(err, null);
                                    }

                                });
                                //callback(null,row);
                                var sqlQuery4 = "Select max(ResQusCountryID) as ResQusCountryID From ResidencyQuestionnariesCountry where ResQusID='" + ResidencyID + "'";
                                //var exQuery3 = sqlQuery3 + "('" + event.UserID + "','" + event.ResStatus + "')";
                                connection.query(sqlQuery4, function (err, result) {
                                    if (err) {
                                        callback(err, null);
                                    }
                                    var countryID = result[0].ResQusCountryID;
                                    // country.push(result[0]);
                                    //callback(null, result);
                                    //check whether this company data already inserted or not
                                    var getCompany = "select EmpCompanyID from ResidencyQuestionnariesEmpCompany where CompanyCode='" + event.companyName + "' and ResQusCountryID='" + countryID + "' and ResQusID='" + ResidencyID + "'";
                                    //EXECUTE THE QUERY
                                    connection.query(getCompany, function (err, companyResult) {
                                        if (err) {
                                            callback(err, null);
                                        }
                                        if (companyResult[0] == null) {
                                            var ResidencyCountryID = '';
                                            var sqlQuery4 = "Select max(ResQusCountryID) as ResQusCountryID From ResidencyQuestionnariesCountry where ResQusID='" + ResidencyID + "'";
                                            connection.query(sqlQuery4, function (err, result) {
                                                if (err) {
                                                    callback(err, null);
                                                }
                                                ResidencyCountryID = result[0].ResQusCountryID;
                                                //callback(null, result[0].ResQusCountryID);

                                                var addCompany_exQuery = "insert into ResidencyQuestionnariesEmpCompany(CompanyCode,Entitle_GPA_Contact,Employee_Closed_Plan,Best_Of_Knowledge,Closed_Plan,ResQusCountryID,ResQusID) VALUES";
                                                var addCompany_sqlQuery = addCompany_exQuery + "('" + event.companyName + "','" + event.companyNameQtns1 + "','" + event.companyNameQtns2 + "','" + event.companyNameQtns3 + "','" + event.companyNameQtns4 + "','" + ResidencyCountryID + "','" + ResidencyID + "')";
                                                connection.query(addCompany_sqlQuery, function (err, row) {
                                                    if (err) {
                                                        callback(err, null);
                                                    }
                                                    connection.release();
                                                    callback(null, row);
                                                });
                                            });
                                        } else {
                                            connection.release();
                                            callback(null, companyResult);
                                        }
                                    })
                                })

                            } else {
                                //check whether this company data already inserted or not
                                var ResidencyCountryID = '';
                                var sqlQuery4 = "Select max(ResQusCountryID) as ResQusCountryID From ResidencyQuestionnariesCountry where ResQusID='" + ResidencyID + "'";
                                connection.query(sqlQuery4, function (err, result) {
                                    if (err) {
                                        callback(err, null);
                                    }
                                    ResidencyCountryID = result[0].ResQusCountryID;

                                    var getCompany = "select EmpCompanyID from ResidencyQuestionnariesEmpCompany where CompanyCode='" + event.companyName + "' and ResQusCountryID='" + ResidencyCountryID + "' and ResQusID='" + ResidencyID + "'";
                                    //EXECUTE THE QUERY
                                    connection.query(getCompany, function (err, row) {
                                        if (err) {
                                            callback(err, null);
                                        }
                                        if (row[0] == null) {
                                            var ResidencyCountryID = '';
                                            var sqlQuery4 = "Select max(ResQusCountryID) as ResQusCountryID From ResidencyQuestionnariesCountry where ResQusID='" + ResidencyID + "'";
                                            connection.query(sqlQuery4, function (err, result) {
                                                if (err) {
                                                    callback(err, null);
                                                }
                                                ResidencyCountryID = result[0].ResQusCountryID;
                                                //callback(null, result[0].ResQusCountryID);

                                                var addCompany_exQuery = "insert into ResidencyQuestionnariesEmpCompany(CompanyCode,Entitle_GPA_Contact,Employee_Closed_Plan,Best_Of_Knowledge,Closed_Plan,ResQusCountryID,ResQusID) VALUES";
                                                var addCompany_sqlQuery = addCompany_exQuery + "('" + event.companyName + "','" + event.companyNameQtns1 + "','" + event.companyNameQtns2 + "','" + event.companyNameQtns3 + "','" + event.companyNameQtns4 + "','" + ResidencyCountryID + "','" + ResidencyID + "')";
                                                connection.query(addCompany_sqlQuery, function (err, row) {
                                                    if (err) {
                                                        callback(err, null);
                                                    }
                                                    connection.release();
                                                    callback(null, row);
                                                });
                                            });
                                        } else {
                                            connection.release();
                                            callback(null, "record already existed");
                                        }
                                    })
                                }); //end country load functions
                            }
                        }) //end residency questionari id getting query
                    })
                    //end else below curely braces }
                }
            });
            if (event.UpdatedStatus == "Yes") {
                var sqlResidency = "SELECT max(ResQusID) as ResQusID FROM gpadatabase.ResidencyQuestionnaries where UserID = '" + event.UserID + "'";
                connection.query(sqlResidency, function (err, row) {
                    if (err) {
                        callback(err, null);
                    }
                    var ResidencyID = row[0].ResQusID;

                    var getCompany = "update ResidencyQuestionnaries set ResQusStatus='" + event.ResStatus + "' where ResQusID = '" + ResidencyID + "'";
                    //EXECUTE THE QUERY
                    connection.query(getCompany, function (err, row) {
                        if (err) {
                            callback(err, null);
                        }
                        // callback(null, "updated successfully");
                    });
                })
            }
        }
        else if (QueryRunMode == "CheckStatus") {
            var getCompany = "Select ResQusStatus from gpadatabase.ResidencyQuestionnaries where UserID='" + event.UserID + "'"
            //EXECUTE THE QUERY
            connection.query(getCompany, function (err, row) {
                if (err) {
                    callback(err, null);
                }
                connection.release();
                callback(null, row[0]);
            });
        }
        else {
            connection.release();
            callback(null, "you entered wrong data");
        }

    });
}
