var mysql = require('mysql');

var pool = mysql.createPool({
    connectionLimit: 100,
    host: 'dev-dbinstance.ci933tgd61ld.us-west-2.rds.amazonaws.com',
    user: 'root',
    password: 'unhappyorangeturtlE',
    database: 'gpadatabase'
});
exports.handler = function (event, context, callback) {
    context.callbackWaitsForEmptyEventLoop = false;
    pool.getConnection(function (err, connection) {
        if (err) {
            var n = 0;
            callback(err, null);
        }
     //var QueryRunMode = event.queryMode;
        //if(QueryRunMode=="GetCountryData"){
              var query = "Insert into UserCompletionStatus(UserID,Applied_Date,FormApplied)values('"+event.UserID+"','"+event.AppliedDate+"','"+event.AppliedForm+"')";
                connection.query(query, function (error, res) {
                if (error) {
                  callback(error, null);
                } else {
                    connection.release();
                    callback(null,res);
                }
              }); 
        //}
    

    });
}
