var mysql = require('mysql');
var connection = mysql.createConnection({
 connectionLimit: 10,
 host: 'dev-dbinstance.ci933tgd61ld.us-west-2.rds.amazonaws.com',
 user: 'root',
 password: 'unhappyorangeturtlE',
 database: 'gpadatabase'
});

exports.handler = (event, context, callback) => {
 context.callbackWaitsForEmptyEventLoop = false;
 var sql;
 var QueryName=event.QueryName;
 var CountryID = event.CountryID;
 var CountryCode = event.CountryCode;
 var CountryName= event.CountryName;
 var IsActive = event.IsActive;
 if(QueryName=="Save")
 {
    sql = "insert into Countries ( CountryCode,CountryName,IsActive ) values('"+CountryCode+"','"+CountryName +"','"+IsActive+"')";
 }
 if(QueryName=="Edit")
 {
    sql= "select * from Countries where CountryID ='"+CountryID +"'";
 }
 if(QueryName=="Update")
 {
     sql= "update Countries set CountryCode ='"+CountryCode +"',CountryName='"+CountryName  +"',IsActive='"+IsActive+"' where CountryID ='"+CountryID +"'";
 }
 if(QueryName=="Delete")
 {
     sql= "update Countries set IsActive='N' where CountryID ='"+CountryID +"'";
 }
 if(QueryName == "Read")
 {
     sql="select CountryID,CountryCode,CountryName,(CASE WHEN IsActive='Y' THEN 'Yes' WHEN IsActive='N' THEN 'No' ELSE '' END) As IsActive from Countries order by IsActive Desc";
 }
  connection.query(sql, function (error, results, fields) {
    if (error) {
      console.log(error);
      callback(error, null);
    } else {
      console.log(results);
      callback(null, results);
    }
    //process.exit();
  });
}