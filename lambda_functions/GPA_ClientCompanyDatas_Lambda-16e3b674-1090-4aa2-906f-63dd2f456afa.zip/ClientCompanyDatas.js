var mysql = require('mysql');
const AWS = require('aws-sdk');
var s3 = new AWS.S3();
var connection = mysql.createConnection({
  connectionLimit: 10,
  host: 'dev-dbinstance.ci933tgd61ld.us-west-2.rds.amazonaws.com',
  user: 'root',
  password: 'unhappyorangeturtlE',
  database: 'gpadatabase'
});

exports.handler = (event, context, callback) => {
  context.callbackWaitsForEmptyEventLoop = false;
  var sql;
  var QueryName=event.QueryName;
  var UserID=event.UserID;
  var CompanyCode= event.CompanyCode;
  var CompanyName=event.CompanyName;
  var Address=event.Address;
  var CountryCode=event.Country;
  var ContactPerson1=event.ContactPerson1;
  var ContactPerson2=event.ContactPerson2;
  var ContactPerson3=event.ContactPerson3;
  var IndustryCode=event.IndustryState;
  var CompanyProductDesc = event.CompanyProductDesc;
  var PhoneNum = event.PhoneNum;
  var FaxNo = event.FaxNo;
  var CompanyWebsite = event.CompanyWebsite;
  var EmailState = event.EmailState;
  var IsActive=event.IsActive;
  var data;
  
  if(QueryName=="Save")
  {
    sql = "insert into ClientCompanies(CompanyCode,CompanyName,Address,CountryCode,ContactPerson1,ContactPerson2,ContactPerson3,NoOfEmployees,IndustryCode,CompanyProductDesc,TelePhoneNum,Fax,Website,Email,CompanyLogo) values ('"+event.CompanyCode+"','"+event.CompanyName+"','"+event.Address+"','"+event.Country+"','"+event.ContactPerson1+"','"+event.ContactPerson2+"','"+event.ContactPerson3+"','"+event.NoOfEmployee+"','"+event.IndustryState+"','"+event.CompanyProductDesc+"','"+event.PhoneNum+"','"+event.FaxNo+"','"+event.CompanyWebsite+"','"+event.EmailState+"','"+"test"+"')";
  }
  if(QueryName=="Update")
  {
  var encodedImage = event.imagePreviewUrl;
  let decodedImage = Buffer.from(encodedImage, 'base64');
  var now = Date.now();
  var filePath = "clientlogo"+now + ".jpg";
  var params = {
      "Body": decodedImage,
      "Bucket": "gpa-dev-mitosis",
      "Key": filePath  
    };
    //console.log(params);
    s3.upload(params, function(err, data){
       if(err) {
           callback(err, null);
       } else { 
    sql = "update ClientCompanies set CompanyCode='"+event.CompanyCode+"',CompanyName='"+event.CompanyName+"',Address='"+event.Address+"',CountryCode='"+event.Country+"',ContactPerson1='"+event.ContactPerson1+"',ContactPerson2='"+event.ContactPerson2+"',ContactPerson3='"+event.ContactPerson3+"',NoOfEmployees='"+event.NoOfEmployee+"',IndustryCode='"+event.IndustryState+"',CompanyProductDesc='"+event.CompanyProductDesc+"',TelePhoneNum='"+event.PhoneNum+"',Fax='"+event.FaxNo+"',Website='"+event.CompanyWebsite+"',Email='"+event.EmailState+"',CompanyLogo='"+data.Location+"' where CompanyID='"+event.CompanyID+"'";
    connection.query(sql, function (error, results, fields) {
    if (error) {
      console.log(sql);
      console.log("fail");
      console.log(error);
      callback(error, null);
    } else {
      console.log("success");
      console.log(results);
      callback(null, results);
    }
    //process.exit();
  });
  }
    });
       }
  if(QueryName=="Delete")
  {
    sql = "update ClientCompanies set IsActive='N' where CompanyCode='"+event.CompanyCode+"'";
  }
  if(QueryName=="Edit")
  {
    sql = "select * from ClientCompanies where CompanyCode='"+event.CompanyCode+"'";
  }
   if(QueryName=="Read")
  {
    sql = "select Cli.CompanyCode,Cli.CompanyName,Cli.Address,Cou.CountryName,Cli.ContactPerson1,Cli.ContactPerson2,Cli.ContactPerson3,Cli.NoOfEmployees,Ind.IndustryName,Cli.CompanyProductDesc,Cli.TelePhoneNum,Fax,Cli.Website,Cli.Email,Cli.CompanyLogo from ClientCompanies Cli inner join Countries Cou on Cli.CountryCode=Cou.CountryCode left join Industries Ind on Cli.IndustryCode=Ind.IndustryCode Where Cli.IsActive='Y'";
  }
  connection.query(sql, function (error, results, fields) {
    if (error) {
      console.log(sql);
      console.log("fail");
      console.log(error);
      callback(error, null);
    } else {
      console.log("success");
      console.log(results);
      callback(null, results);
    }
    //process.exit();
  });
}
