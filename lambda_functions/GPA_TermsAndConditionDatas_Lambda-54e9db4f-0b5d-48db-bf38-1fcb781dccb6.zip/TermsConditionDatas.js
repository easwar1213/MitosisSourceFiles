var mysql = require('mysql');
var connection = mysql.createConnection({
  connectionLimit: 10,
  host: 'dev-dbinstance.ci933tgd61ld.us-west-2.rds.amazonaws.com',
  user: 'root',
  password: 'unhappyorangeturtlE',
  database: 'gpadatabase'
});

exports.handler = (event, context, callback) => {
  context.callbackWaitsForEmptyEventLoop = false;
  var sql;
  var QueryName=event.QueryName;
  var UserID=event.UserID;
  var UserID=event.UserID;
  var FirstName=event.FirstName;
  var MiddleName=event.MiddleName;
  var LastName=event.LastName;
  var DateOfSigned=event.DateOfSigned;
  var SignedBy=event.SignedBy;
  var SignedByName=event.SignedByName;
  var Signature=event.Signature;
  var TCStatus=event.TCStatus;
  if(QueryName=="Save")
  {
    sql = "insert into UserTermsConditions(UserID,FirstName,MiddleName,LastName,DateOfSigned,SignedBy,SignedByName,Signature,TCStatus) values('"+UserID+"','"+FirstName+"','"+MiddleName+"','"+LastName+"','"+DateOfSigned+"','"+SignedBy+"','"+SignedByName+"','"+Signature+"','"+TCStatus+"')";
  }
  if(QueryName=="Read")
  {
    sql = "select * from UserTermsConditions Where UserID='"+UserID+"'";
  }
  connection.query(sql, function (error, results, fields) {
    if (error) {
      console.log(error);
      callback(error, null);
    } else {
      console.log(results);
      callback(null, results);
    }
    //process.exit();
  });
}