
exports.handler = function(event, context,callback) {
    
	const AWS = require('aws-sdk');
    var s3 = new AWS.S3();
    //S3 Path Setup
    var MainFolderName=event.MainFolderName;
    var SubFolderName=event.SubFolderName;
    var MailDocName=event.MailDocName;
    var LangCode=event.LangCode;
    var FCLType=event.FCLType;
    //Mail Setup
    var EmailTo=event.EmailTo;
    var User;
    var Pwd;
    var FileName;
    var MailSubject;
    var MailContent;
    var AttachFileName;
    if(MailDocName=="POA")
    {
        User="no-reply@globalpensionassociates.com";
        Pwd="Markrocks2018";
        MailSubject="GPA-Power Of Attorney"
        MailContent="Please find the below attached Power Of Attorney Form.You could take 3 hard copy of POA and signed & send back to GPA."
        AttachFileName="PowerOfAttorney.pdf";
        FileName=MainFolderName+"/"+SubFolderName+"/"+"poa_"+LangCode+".pdf";
    }
    if(MailDocName=="TC")
    {
        User="no-reply@globalpensionassociates.com";
        Pwd="Markrocks2018";
        MailSubject="GPA-Copy of Terms and Condition"
        MailContent="Please find the below attached Terms and Condition."
        AttachFileName="Terms_and_Conditions.pdf";
        FileName=MainFolderName+"/"+SubFolderName+"/"+"tc_"+LangCode+".html.pdf";
    }
    if(MailDocName=="FCL")
    {
        User="no-reply@globalpensionassociates.com";
        Pwd="Markrocks2018";
        if(FCLType=="Pre")
        {
            MailSubject="GPA-Pre Forecast Letter"
            MailContent="Please find the below attached Pre Forecast Letter."
            AttachFileName="Pre_Forecast_Letter.pdf";
            FileName=MainFolderName+"/"+SubFolderName+"/"+"prefcl_"+LangCode+".html.pdf";
        }
        if(FCLType=="Post")
        {
            MailSubject="GPA-Post Forecast Letter"
            MailContent="Please find the below attached Post Forecast Letter."
            AttachFileName="Post_Forecast_Letter.pdf";
            FileName=MainFolderName+"/"+SubFolderName+"/"+"postfcl_"+LangCode+".html.pdf";
        }
    }
    
    var email 	= require("emailjs/email");
    var server 	= email.server.connect({
        user:    User, 
		password:Pwd, 
		host:    "smtp.gmail.com",
		ssl:     true,
        timeout: 100000
    });
    var params = {
        "Bucket": "gpa-dev-mitosis",
        "Key": FileName
    };
    
       s3.getObject(params, function(err, data){
       if(err) {
           callback(err, null);
       } else {
           let response = {
        "statusCode": 200,
        "headers": {
            "my_header": "my_value"
        },
        "body": new Buffer(data.Body, 'binary').toString('base64')
    };
      server.send({
		  text:    MailContent, 
		  from:    User, 
		  to:      EmailTo,
		//cc:      "else <else@your-email.com>",
		  subject: MailSubject,
		 attachment: [
			{data: data.Body.toString('base64'), encoded:true, type:"application/pdf", name:AttachFileName}
		  ]
	   }, function(err, message) 
	        { 
	            if(err){
	                callback(err,null);
	            }else{
	                callback(null,message);
	            }
	            console.log(err || message); 
	            
	        }
	  );
    }
    });
    
    if(event.MailDocName=="SendNotificationMail"){
        
       var User="no-reply@globalpensionassociates.com";
       var Pwd="Markrocks2018";
       var MailSubject="Global Pension Associates";
       var EmailTo="baladgct@gmail.com";
      
    var email 	= require("emailjs/email");
    var server 	= email.server.connect({
        user:    User, 
		password:Pwd, 
		host:    "smtp.gmail.com",
		ssl:     true,
        timeout: 100000
    });
    var MailContent="Application Denied"+event.CountryName+"";
       server.send({
		  text:    MailContent, 
		  from:    User, 
		  to:      EmailTo,
		//cc:      "else <else@your-email.com>",
		  subject: MailSubject
	
	   }, function(err, message) 
	        { 
	            if(err){
	                callback(err,null);
	            }else{
	                callback(null,message);
	            }
	            console.log(err || message); 
	            
	        }
	  );
    }
     if(event.MailDocName=="ApplicantDeniedMail"){
        
       var User="no-reply@globalpensionassociates.com";
       var Pwd="Markrocks2018";
       var MailSubject="Global Pension Associates";
       var EmailTo=event.UserID;//"pitchaimuthu.k@mitosistech.com";//event.UserID
      
    var email 	= require("emailjs/email");
    var server 	= email.server.connect({
        user:    User, 
		password:Pwd, 
		host:    "smtp.gmail.com",
		ssl:     true,
        timeout: 100000
    });
    var MailContent="You are not eligible due to number of years. GPA will continue looking into private pension options if applicable.";
       server.send({
		  text:    MailContent, 
		  from:    User, 
		  to:      EmailTo,
		//cc:      "else <else@your-email.com>",
		  subject: MailSubject
	
	   }, function(err, message) 
	        { 
	            if(err){
	                callback(err,null);
	            }else{
	                callback(null,message);
	            }
	            console.log(err || message); 
	            
	        }
	  );
    }
}