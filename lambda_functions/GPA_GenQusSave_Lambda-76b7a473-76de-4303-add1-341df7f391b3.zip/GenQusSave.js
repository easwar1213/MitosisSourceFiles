var mysql = require('mysql');
var connection = mysql.createConnection({
 connectionLimit: 10,
 host: 'dev-dbinstance.ci933tgd61ld.us-west-2.rds.amazonaws.com',
 user: 'root',
 password: 'unhappyorangeturtlE',
 database: 'gpadatabase'
});

exports.handler = (event, context, callback) => {
 context.callbackWaitsForEmptyEventLoop = false;
 var UserID=event.UserID;
 var InquiryAbout=event.InquiryAbout;
 var AreYou=event.AreYou;
 var Gender=event.Gender;
 var Title=event.Title;
 var FirstName=event.FirstName;
 var MiddleName=event.MiddleName;
 var LastName=event.LastName;
 var Suffix=event.Suffix;
 var BirthName=event.BirthName;
 var MaidenName=event.MaidenName;
 var DOB_Day=event.DOB_Day;
 var DOB_Month=event.DOB_Month;
 var DOB_Year=event.DOB_Year;
 var CountryOfCitizenship=event.CountryOfCitizenship;
 var MailingAddress=event.MailingAddress;
 var PhoneNum=event.PhoneNum;
 var HomeNum=event.HomeNum;
 var MaritalStatus=event.MaritalStatus;
 var DOB_Marri_Death_Divorce_Day=event.DOB_Marri_Death_Divorce_Day;
 var DOB_Marri_Death_Divorce_Month=event.DOB_Marri_Death_Divorce_Month;
 var DOB_Marri_Death_Divorce_Year=event.DOB_Marri_Death_Divorce_Year;
 var P_Gender=event.P_Gender;
 var P_Title=event.P_Title;
 var P_FirstName=event.P_FirstName;
 var P_MiddleName=event.P_MiddleName;
 var P_LastName=event.P_LastName;
 var P_Suffix=event.P_Suffix;
 var P_DOB_Day=event.P_DOB_Day;
 var P_DOB_Month=event.P_DOB_Month;
 var P_DOB_Year=event.P_DOB_Year;
 var P_CountryOfCitizenship=event.P_CountryOfCitizenship;
 var P_MailingAddress=event.P_MailingAddress;
 var GenQusStatus=event.GenQusStatus;
  var sql = "insert into GeneralQuestionnaries (UserID,InquiryAbout,AreYou,Gender,Title,FirstName,MiddleName,LastName,Suffix,BirthName,MaidenName,DOB_Day,DOB_Month,DOB_Year,CountryOfCitizenship,MailingAddress,PhoneNum,HomeNum,MaritalStatus,DOMCDW_Day,DOMCDW_Month,DOMCDW_Year,PGender,PTitle,PFirstName,PMiddleName,PLastName,PSuffix,PDOB_Day,PDOB_Month,PDOB_Year,PCountryOfCitizenship,PMailingAddress,GenQusStatus) values('"+UserID+"','"+InquiryAbout+"','"+AreYou+"','"+Gender+"','"+Title+"','"+FirstName+"','"+MiddleName+"','"+LastName+"','"+Suffix+"','"+BirthName+"','"+MaidenName+"','"+DOB_Day+"','"+DOB_Month+"','"+DOB_Year+"','"+CountryOfCitizenship+"','"+MailingAddress+"','"+PhoneNum+"','"+HomeNum+"','"+MaritalStatus+"','"+DOB_Marri_Death_Divorce_Day+"','"+DOB_Marri_Death_Divorce_Month+"','"+DOB_Marri_Death_Divorce_Year+"','"+P_Gender+"','"+P_Title+"','"+P_FirstName+"','"+P_MiddleName+"','"+P_LastName+"','"+P_Suffix+"','"+P_DOB_Day+"','"+P_DOB_Month+"','"+P_DOB_Year+"','"+P_CountryOfCitizenship+"','"+P_MailingAddress+"','"+GenQusStatus+"')";
  connection.query(sql, function (error, results, fields) {
    if (error) {
      console.log(error);
      callback(error, null);
    } else {
      console.log(results);
      callback(null, results);
    }
    //process.exit();
  });
}