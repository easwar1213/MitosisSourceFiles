var mysql = require('mysql');

var pool = mysql.createPool({
    connectionLimit: 100,
    host: "127.0.0.1",
    user: "root",
    password: "Admin@123",
    database: "testing"
});
exports.handler=function(event,context,callback)
{
context.callbackWaitsForEmptyEventLoop=false;

pool.getConnection(function (error, connection) {
    if (error) {
        console.log("connectionerror");
        callback(error,null);
    }
    
    else {
        var query = "select * from testingnew";

        connection.query(query, function (error, result) {
            console.log(result);
            if(error)
            {
                callback(error,null);
            }
            else{
                callback(null,result);
            }
        })
    }
})
}

// var mysql = require('mysql');

// var con = mysql.createConnection({
//  host: "localhost",
//  user: "root",
//  password: "Admin@123",
//  database:"testing"
// });

// con.connect(function(err) {
//  if (err) throw err;
//  console.log("Connected!");
// });