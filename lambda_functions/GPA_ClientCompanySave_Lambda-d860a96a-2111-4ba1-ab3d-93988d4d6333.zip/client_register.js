const AWS = require('aws-sdk');
var mysql = require('mysql');
var s3 = new AWS.S3();
var pool = mysql.createPool({
    connectionLimit:10,
    host: 'dev-dbinstance.ci933tgd61ld.us-west-2.rds.amazonaws.com',
    user: 'root',
    password: 'unhappyorangeturtlE',
    database: 'gpadatabase'
});
exports.handler = function(event, context, callback){
    context.callbackWaitsForEmptyEventLoop = false;
    pool.getConnection(function(err, connection){
    if(err){
        connection.release();
    }
 var CompanyCode= event.CompanyCode;
 var CompanyName=event.CompanyName;
 var Address=event.Address;
 var CountryCode=event.Country;
 var ContactPerson1=event.ContactPerson1;
 var ContactPerson2=event.ContactPerson2;
 var ContactPerson3=event.ContactPerson3;
 var NoOfEmployees=event.NoOfEmployee;
 var IndustryCode=event.IndustryState;
 var CompanyProductDesc = event.CompanyProductDesc;
 var PhoneNum = event.PhoneNum;
 var FaxNo = event.FaxNo;
 var CompanyWebsite = event.CompanyWebsite;
 var EmailState = event.EmailState;
 let encodedImage = event.imagePreviewUrl;
     let decodedImage = Buffer.from(encodedImage, 'base64');
     var now = Date.now();
     var filePath = "clientlogo"+now + ".jpg";
     var params = {
       "Body": decodedImage,
       "Bucket": "gpa-dev-mitosis",
       "Key": filePath  
    };
    s3.upload(params, function(err, data){
       if(err) {
           callback(err, null);
       } else {
          let response = {
        "statusCode": 200,
        "headers": {
            "my_header": "my_value"
        },
        "body": JSON.stringify(data),
        "isBase64Encoded": false
    };
          //callback(null, response);
          console.log("location"+data.Location);
    var sqlQuery = "INSERT INTO ClientCompanies(CompanyCode,CompanyName,Address,CountryCode,ContactPerson1,ContactPerson2,ContactPerson3,NoOfEmployees,IndustryCode,CompanyProductDesc,TelePhoneNum,Fax,Website,Email,CompanyLogo) VALUES";
    var exQuery = sqlQuery+"('"+event.CompanyCode+"','"+event.CompanyName+"','"+event.Address+"','"+event.Country+"','"+event.ContactPerson1+"','"+event.ContactPerson2+"','"+event.ContactPerson3+"','"+event.NoOfEmployee+"','"+event.IndustryState+"','"+event.CompanyProductDesc+"','"+event.PhoneNum+"','"+event.FaxNo+"','"+event.CompanyWebsite+"','"+event.EmailState+"','"+data.Location+"')";
    console.log(exQuery);
    connection.query(exQuery,function(err,row){
        if(err){
            callback(err,null);
        }else{
            callback(null,row);
        }
    });
       }
    });
    });
    }