var mysql = require('mysql');
var pool = mysql.createPool({
    connectionLimit:10,
    host: 'dev-dbinstance.ci933tgd61ld.us-west-2.rds.amazonaws.com',
    user: 'root',
    password: 'unhappyorangeturtlE',
    database: 'gpadatabase'
});
exports.handler = function(event, context, callback){
    context.callbackWaitsForEmptyEventLoop = false;
pool.getConnection(function(err, connection){
    if(err){
        connection.release();
    }
 var Lastname=event.Lastname;

 var ZipCode=event.ZipCode;
 var CountryFlag=event.CountryFlag;
 var Mobileno=event.Mobileno;
 var State=event.State;
 var City=event.City;
 var Address=event.Address;
 var sqlQuery = "INSERT INTO Client_Registration(Lastname,ZipCode,CountryFlag,Mobileno,State,City,Address) VALUES";
    var exQuery = sqlQuery+"('"+event.Lastname+"','"+event.ZipCode+"','"+event.CountryFlag+"','"+event.Mobileno+"','"+event.State+"','"+event.City+"','"+event.Address+"')";
    connection.query(exQuery,function(err,row){
        if(err){
            callback(err,null);
        }else{
            callback(null,row);
        }
    });
});
}




var aws = require('aws-sdk');
var ses = new aws.SES({
   region: 'us-west-2'
});
exports.handler = function(event, context) {
    var emailList = event.result1
    console.log(emailList)
    console.log("Incoming: ", event);
   // var output = querystring.parse(event);

    var eParams = {
        Destination: {
            ToAddresses: ["sathiyan.s@mitosistech.com"]
        },
        Message: {
            Body: {
                Text: {
                    Data: "http://202.61.120.46:3001/"
                }
            },
            Subject: {
                Data: "Email Subject!!!"
            }
        },
        Source: "easwaran.k@mitosistech.com"
    };

    console.log('===SENDING EMAIL===');
    var email = ses.sendEmail(eParams, function(err, data){
        if(err) console.log(err);
        else {
            console.log("===EMAIL SENT===");
            console.log(data);


            console.log("EMAIL CODE END");
            console.log('EMAIL: ', email);
            context.succeed(event);

        }
    });

};