var mysql = require('mysql');
var connection = mysql.createConnection({
 connectionLimit: 10,
 host: 'dev-dbinstance.ci933tgd61ld.us-west-2.rds.amazonaws.com',
 user: 'root',
 password: 'unhappyorangeturtlE',
 database: 'gpadatabase'
});
exports.handler = (event, context, callback) => {
 context.callbackWaitsForEmptyEventLoop = false;
 var UserID=event.UserID;
 var sql="select Ben.HomeAddress,Ben.PlaceOfBirth,Ben.Partner,Cou.CountryName,Ben.Benefits,Ben.BenefitsName,Ben.GetBenefits,Ben.Receiving,Ben.ReferenceNum,Ben.SSSecurity,Ben.SSSecurityAddress,Ben.DateOfBenefits,Com.CompanyName,Ben.Occupation,Ben.CompanyAddress,Ben.EligibleCountry,Ind.IndustryName from BenQusCountryInGPA Ben left join Countries Cou on Ben.CountryCode=Cou.CountryCode left join ClientCompanies Com on Ben.CompanyCode=Com.CompanyCode left join Industries Ind on Ben.IndustryCode=Ind.IndustryCode where Ben.UserID='"+UserID+"' ";
 connection.query(sql, function (error, results, fields) {
    if (error) {
      console.log(error);
      callback(error, null);
    } else {
      console.log(results);
      callback(null, results);
    }
    //process.exit();
  });
}