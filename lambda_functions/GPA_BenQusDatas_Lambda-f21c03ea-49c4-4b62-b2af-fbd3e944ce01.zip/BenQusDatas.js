var mysql = require('mysql');

var pool = mysql.createPool({
    connectionLimit: 100,
    host: 'dev-dbinstance.ci933tgd61ld.us-west-2.rds.amazonaws.com',
    user: 'root',
    password: 'unhappyorangeturtlE',
    database: 'gpadatabase'
});
exports.handler = function (event, context, callback) {
    context.callbackWaitsForEmptyEventLoop = false;
    pool.getConnection(function (err, connection) {
        if (err) {
            var n = 0;
            callback(err, null);
        }
        var sql;
        var QueryName = event.QueryName;
        var UserID=event.UserID;
        var CountryCode=event.CountryCode;
        var AppAnsInJsonObj=JSON.stringify(event.AppAnsInJsonObj);
        
        if(QueryName=="Save"){
              sql = "insert into BenQusCountryNotInGPA(UserID,CountryCode,AppAnsInJsonObj) values ('"+UserID+"','"+CountryCode+"','"+AppAnsInJsonObj+"')";
                connection.query(sql, function (error, res) {
                if (error) {
                  callback(error, null);
                } else {
                    connection.release();
                    callback(null,res);
                }
              }); 
        }else{
               callback(null,"no data");
        }

    });
}
