const AWS = require('aws-sdk');
var mysql = require('mysql');
var s3 = new AWS.S3();
var pool = mysql.createPool({
    connectionLimit:10,
    host: 'dev-dbinstance.ci933tgd61ld.us-west-2.rds.amazonaws.com',
    user: 'root',
    password: 'unhappyorangeturtlE',
    database: 'gpadatabase'
});
exports.handler = function(event, context, callback){
    context.callbackWaitsForEmptyEventLoop = false;
pool.getConnection(function(err, connection){
    if(err){
        connection.release();
    }
  var DeleteLogo = "select CompanyLogo from ClientCompany where CompanyID='"+event.CompanyID+"'";
  s3.deleteObject({
  Bucket: "gpa-dev-mitosis",
  Key: DeleteLogo
},function (err,data){
    if (err) {
                  console.log(err);
                } else {
                    console.log(data);
                }
});
 var CompanyName=event.CompanyName;
 var ZipCode=event.ZipCode;
 var Country=event.Country;
 var Mobileno=event.PhoneNum;
 var State=event.State;
 var City=event.City;
 var Address=event.Address;
  let encodedImage = event.imagePreviewUrl;
     let decodedImage = Buffer.from(encodedImage, 'base64');
     var now = Date.now();
     var filePath = "clientlogo"+now + ".jpg";
    // var filePath = "testclientlogo03.jpg";
     var params = {
       "Body": decodedImage,
       "Bucket": "gpa-dev-mitosis",
       "Key": filePath  
    };
    s3.upload(params, function(err, data){
       if(err) {
           callback(err, null);
       } else { 
          let response = {
        "statusCode": 200,
        "headers": {
            "my_header": "my_value"
        },
        "body": JSON.stringify(data),
        "isBase64Encoded": false
    };
   // callback(null, response);
    console.log("location"+data.Location);
    console.log(sqlQuery);
    var sqlQuery = "update ClientCompanies set CompanyCode='"+event.CompanyCode+"',CompanyName='"+event.CompanyName+"',Address='"+event.Address+"',CountryCode='"+event.Country+"',ContactPerson1='"+event.ContactPerson1+"',ContactPerson2='"+event.ContactPerson2+"',ContactPerson3='"+event.ContactPerson3+"',NoOfEmployees='"+event.NoOfEmployee+"',IndustryCode='"+event.IndustryState+"',CompanyProductDesc='"+event.CompanyProductDesc+"',TelePhoneNum='"+event.PhoneNum+"',Fax='"+event.FaxNo+"',Website='"+event.CompanyWebsite+"',Email='"+event.EmailState+"',CompanyLogo='"+data.Location+"' where CompanyCode='"+event.CompanyCode+"'";
    connection.query(sqlQuery,function(err,row){
        if(err){
            console.log("error")
            callback(err,null);
        }else{
            console.log("success");
            callback(null,row);
        }
    });
       }
    });
});
}