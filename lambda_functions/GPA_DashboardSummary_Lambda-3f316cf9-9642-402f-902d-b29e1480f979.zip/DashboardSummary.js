var mysql = require('mysql');
var connection = mysql.createConnection({
  connectionLimit: 10,
  host: 'dev-dbinstance.ci933tgd61ld.us-west-2.rds.amazonaws.com',
  user: 'root',
  password: 'unhappyorangeturtlE',
  database: 'gpadatabase'
});

exports.handler = (event, context, callback) => {
  context.callbackWaitsForEmptyEventLoop = false;
  var UserID=event.UserID;
  var sql = "select G.UserID,G.InquiryAbout,(CASE WHEN G.AreYou='C' THEN 'Current Employee' WHEN G.AreYou='R' THEN 'Retired' ELSE '' END) AS AreYou,(CASE WHEN G.Gender='M' THEN 'Male' WHEN G.Gender='F' THEN 'Female' ELSE '' END) AS Gender,G.Title,G.FirstName,G.MiddleName,G.LastName,G.Suffix,G.BirthName,G.MaidenName,G.DOB_Day,G.DOB_Month,G.DOB_Year,C.CountryName AS CountryOfCitizenship,G.MailingAddress,G.PhoneNum,G.HomeNum,(CASE WHEN G.MaritalStatus='S' THEN 'Single' WHEN G.MaritalStatus='M' THEN 'Married' WHEN G.MaritalStatus='C' THEN 'Civil Partnership' WHEN G.MaritalStatus='D' THEN 'Divorced' WHEN G.MaritalStatus='W' THEN 'Widowed' ELSE '' END) AS MaritalStatus,G.DOMCDW_Day,G.DOMCDW_Month,G.DOMCDW_Year,(CASE WHEN G.Gender='M' THEN 'Male' WHEN G.Gender='F' THEN 'Female' ELSE '' END) AS PGender,G.PTitle,G.PFirstName,G.PMiddleName,G.PLastName,G.PSuffix,G.PDOB_Day,G.PDOB_Month,G.PDOB_Year,C.CountryName AS PCountryOfCitizenship,G.PMailingAddress,(CASE WHEN G.GenQusStatus='P' THEN 'Pending' WHEN G.GenQusStatus='C' THEN 'Completed' ELSE '' END)AS GenQusStatus from GeneralQuestionnaries G inner join Countries C on G.CountryOfCitizenship=C.CountryCode where G.UserID='"+UserID+"'";
  connection.query(sql, function (error, results, fields) {
    if (error) {
      console.log(error);
      callback(error, null);
    } else {
      console.log(results);
      callback(null, results);
    }
    //process.exit();
  });
}